#!/usr/bin/env python2
# -*- coding: UTF-8 -*-

############## Import global
from lxml import etree
from os.path import join, dirname

############## Import local
from exercices_actimaths.exercices_actimaths import creation

############## lis le fichier listant les exercices au format xml
def lire_liste_exercice(file):
    tree = etree.parse(file)
    root = tree.getroot()
    liste = []
    for onglet in root.iter("onglet"):
        nom_onglet = onglet.get("nom")
        liste_categorie = []
        for categorie in onglet.iter("categorie"):
            nom_categorie = categorie.get("nom")
            liste_exercice = []
            for exercice in categorie.iter("exercice"):
                nom_exercice = exercice.get("nom")
                commande_exercice = exercice.get("commande")
                liste_parametre = []
                for parametre in exercice.iter("parametre"):
                    nom_parametre = parametre.get("nom")
                    min_parametre = parametre.get("min")
                    max_parametre = parametre.get("max")
                    defaut_parametre = parametre.get("defaut")
                    liste_parametre.append([nom_parametre, min_parametre, max_parametre, defaut_parametre])
                liste_exercice.append([nom_exercice, liste_parametre, commande_exercice])
            liste_categorie.append([nom_categorie, liste_exercice])
        liste.append([nom_onglet, liste_categorie])
    return liste

############## Creation du menu
def creation_menu(liste_exercice):
    html = ""
    ## Creation du formulaire d'exercices
    for onglet in range(len(liste_exercice)):
        html += u"Niveau = \"%s\" \n""" % liste_exercice[onglet][0]
        # Construction du contenu des onglets
        for categorie in range(len(liste_exercice[onglet][1])):
            html += u"    Domaine = \"%s\" \n" % liste_exercice[onglet][1][categorie][0]
            # Construction de la ligne correspondant à un exercice
            for exercice in range(len(liste_exercice[onglet][1][categorie][1])):
                html += u"        Nom Exercice = \"%s\" " % liste_exercice[onglet][1][categorie][1][exercice][0]
                html += u"Commande = \"%s\" \n" % liste_exercice[onglet][1][categorie][1][exercice][2]
                # Ajout des parametres à la ligne de l'exercice
                for parametre in range(len(liste_exercice[onglet][1][categorie][1][exercice][1])):
                        html += u"            Nom Paramètre = \"%s\" " % liste_exercice[onglet][1][categorie][1][exercice][1][parametre][0]
                        html += u"Min = \"%s\" " % liste_exercice[onglet][1][categorie][1][exercice][1][parametre][1]
                        html += u"Max = \"%s\" \n" % liste_exercice[onglet][1][categorie][1][exercice][1][parametre][2]
    print html.encode('utf-8')

############## Creation des exercices
def creation_exercice(commande,parametre1,parametre2):
    ## Creation de parametre
    parametres = {'sujet_presentation':   True,
                  'corrige_presentation': True,
                  'sujet_page':           True,
                  'corrige_page':         True,
                  'titre':                "Titre de test",
                  'nom_etablissement':    u"Établissement de test",
                  'nom_auteur':           "Auteur de test",
                  'temps_slide':          "10",
                  'date_activite':        "Date de test",
                  'niveau':               "Niveau de test",
                  'nom_fichier':          "exercice",
                  'affichage':            "niveau",
                  'modele_presentation':  "BiColonneIdentique",
                  'modele_page':          "BiColonneIdentique",
                  'chemin_csv':           "",
                  'afficher_pdf':         True,
                  'chemin_fichier':       dirname(__file__)}
    parametres['liste_exercice'] = [(commande, (parametre1,parametre2))]
    ## Creation des exercices
    creation(parametres)

###==============================================================
###                            Main
###==============================================================
def main():
    ## creation du menu
    creation_menu(lire_liste_exercice(join(dirname(__file__),"data", "onglets", "niveau.xml")))
    commande = raw_input("Entrez la commande de l\'exercice : ")
    parametre1 = raw_input("Entrez la valeur du parametre 1 : ")
    parametre2 = raw_input("Entrez la valeur du parametre 2 : ")
    ## creation des exercices
    creation_exercice(commande,parametre1,parametre2)

if __name__ == "__main__":
    main()
